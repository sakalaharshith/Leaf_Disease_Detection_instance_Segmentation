# Leaf_Disease_Detection_Image_Classification
Implementation of leaf disease detection through Image classification using transfer learning approach.
Plant village dataset is used to perform leaf disease detection and 6 classes are picked to perform detection they are:
1) Apple_healthy
2)Apple_Black_rot
3)Grape_healthy
4)Grape_Black_rot
5)Potato_healthy
6)Potato_Late_Blight
The main of this project is to perform leaf disease detection through image classification and also evaluate the performance of image classification technique against same images with background in it.
Two Deep learning architectures have been used to perform image classification they are: InceptionNetv3, EfficientNetB1.

dataset_whole_image_classification: This zip folder contains 6 folders each folder for each class and these folders contains images from plant village dataset.
without_background: This zip folder contains just same as many folders as previous one except that it contains images without background in it.
